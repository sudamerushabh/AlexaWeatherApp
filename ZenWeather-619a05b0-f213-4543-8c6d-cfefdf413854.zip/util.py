import random
import six
from ask_sdk_core.handler_input import HandlerInput
from ask_sdk_core.utils import is_request_type

def get_intent_(slots):
    
    resolved_item = None
    for _,slot in six.iteritems(slots):
        if slot.value is not None:
            resolved_item = slot.value
            
    if resolved_item is not None:
        return resolved_item, True
    else:
        return resolved_item, False